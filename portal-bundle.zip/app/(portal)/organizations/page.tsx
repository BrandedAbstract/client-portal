'use client';
import { useState } from 'react';
import { supabase } from '@/utils/supabaseClient';
import { useRouter } from 'next/navigation';

export default function OrgsPage() {
  const [name, setName] = useState('');
  const router = useRouter();

  async function createOrg(e) {
    e.preventDefault();
    const { error } = await supabase.from('organizations').insert({ name });
    if (!error) router.push('/(portal)');
  }

  return (
    <form onSubmit={createOrg} style={{maxWidth:'300px',color:'white',display:'flex',flexDirection:'column',gap:'8px'}}>
      <h2 style={{fontSize:'18px',fontWeight:'600'}}>New organisation</h2>
      <input
        style={{padding:'8px',borderRadius:'4px'}}
        placeholder="Organisation name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        required
      />
      <button style={{padding:'8px',background:'#500069',borderRadius:'6px',color:'#fff'}}>Save</button>
    </form>
  );
}
export default function Dashboard() {
  return <p style={{color:'white'}}>👋 Portal scaffold works!</p>;
}
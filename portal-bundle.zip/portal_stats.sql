create or replace function org_30day_totals(p_org uuid)
returns table(total_chats int, total_leads int, conversion_rate numeric)
language sql stable as $$
  select
    sum(ds.chats)       as total_chats,
    sum(ds.leads)       as total_leads,
    coalesce(sum(ds.leads)::float / nullif(sum(ds.chats),0),0) as conversion_rate
  from bots b
  join daily_stats ds on ds.bot_id = b.id
  where b.org_id = p_org
    and ds.date >= current_date - interval '30 days';
$$;